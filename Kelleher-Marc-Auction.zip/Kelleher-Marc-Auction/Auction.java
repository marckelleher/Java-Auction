import java.util.ArrayList;

/**
 * A simple model of an auction.
 * The auction maintains a list of lots of arbitrary length.
 *
 * @author David J. Barnes and Michael Kölling.
 * @version 2011.07.31
 * 
 * Modifications:
 * @author MarcKelleher 8/4/15
 * 
 * Added close method.
 * Added getUnsold method.
 * Added removeLot method.
 * Modified method getLot to use the lot number for search unstead of the index number.
 */
public class Auction
{
    // The list of Lots in this auction.
    private ArrayList<Lot> lots;
    private ArrayList<Lot> unsoldLots;
    // The number that will be given to the next lot entered
    // into this auction.
    private int nextLotNumber;
    private int nextUnsoldLotNumber;

    /**
     * Create a new auction.
     */
    public Auction()
    {
        lots = new ArrayList<Lot>();
        nextLotNumber = 1;
    }

    /**
     * Enter a new lot into the auction.
     * @param description A description of the lot.
     */
    public void enterLot(String description)
    {
        lots.add(new Lot(nextLotNumber, description));
        nextLotNumber++;
    }

    /**
     * Show the full list of lots in this auction.
     */
    public void showLots()
    {
        for(Lot lot : lots) 
        {
            System.out.println(lot.toString());
        }
    }
    
    /**
     * Make a bid for a lot.
     * A message is printed indicating whether the bid is
     * successful or not.
     * 
     * @param lotNumber The lot being bid for.
     * @param bidder The person bidding for the lot.
     * @param value  The value of the bid.
     */
    public void makeABid(int lotNumber, Person bidder, long value)
    {
        Lot selectedLot = getLot(lotNumber);
        if(selectedLot != null) 
        {
            Bid bid = new Bid(bidder, value);
            boolean successful = selectedLot.bidFor(bid);
            if(successful) 
            {
                System.out.println("The bid for lot number " +
                                   lotNumber + " was successful.");
            }
            else {
                // Report which bid is higher.
                Bid highestBid = selectedLot.getHighestBid();
                System.out.println("Lot number: " + lotNumber +
                                   " already has a bid of: " +
                                   highestBid.getValue());
            }
        }
    }

    /**
     * Return the lot with the given number. Return null
     * if a lot with this number does not exist.
     * @param lotNumber The number of the lot to return.
     * 
     * Modified:
     * Ex. 4.51
     * @author Marc Kelleher  8/4/15
     * Changed code to find lot by lot number instead of index number.
     * Provided error messages if the lot had been removed or does not exist.
     */
    public Lot getLot(int lotNumber)
    {
        Lot selectedLot = null;
        int index = 0;
        boolean searching = true;
        boolean lotExists = false;
        if((lotNumber >= 1) && (lotNumber < nextLotNumber)) 
        {
            while(searching && index < lots.size())
            {
                 if(lots.get(index).getNumber() == lotNumber)
                 {
                     // The lot is correct, end the search.
                     searching = false;
                     selectedLot = lots.get(index);
                     lotExists = true;
                 }
                 else
                 {
                     //keep searching.
                     index++;
                 }
            }
            if(lotExists)
            {
                return selectedLot;
            }
            else 
            {
                // The lot had already been removed.
                System.out.println("Lot number: " + lotNumber +
                               " no longer exists.");
                return null;
            }
        }
        else 
        {
            System.out.println("Lot number: " + lotNumber +
                               " does not exist.");
            return null;
        }
    }
    
    /**
    * Ex. 4.48
    * Name: close
    * @author Marc Kelleher 8/3/15.
    * Description: Prints out the details of the lots in the collection.
    */
   public void close()
    {
        for(Lot lot : lots) 
        {
            System.out.println(lot.toString());
            
            Bid highestBid = lot.getHighestBid();  //get the highest bid for the lot.
            if(highestBid != null) 
            {
                Person highestBidder = highestBid.getBidder();
                System.out.println(highestBidder.getName() + " " + highestBid);
            }
            else 
            {
                // If no bid has been placed then this message appears.
                System.out.println("Not sold.");
            }
        }
    }
    
    /**     
    * Ex. 4.49
    * Name: getUnsold
    * @author Marc Kelleher 8/3/15.
    * Description: Prints out the lots in the collection that have not been bid on.
    */
   public ArrayList<Lot> getUnsold()
    {
        int nextUnsoldLotNumnber = 1;
        unsoldLots = new ArrayList<Lot>();
        for(Lot lot : lots) 
        {
            nextUnsoldLotNumber = 1;
            // Get the highest bid for the lot.
            Bid highestBid = lot.getHighestBid();  
            if(highestBid != null) 
            {
                return null;    
            }
            else 
            {
                // Add the lot to the new list.
                unsoldLots.add(new Lot(nextLotNumber, lot.getDescription()));
                nextUnsoldLotNumber++;
            }
        }
        return unsoldLots;
    }   
   
   /**
    * Ex. 4.52
    * Name: removeLot
    * @author Marc Kelleher 8/5/15.
    * Description: Remove the lot with the given lot number.
    * @param number The Lot with the given number, or null if
    * there is no such lot.
    */
   public Lot removeLot(int number)
    {
        // Remove the requested lot using the getLot method.
        lots.remove(getLot(number));
        System.out.println("Lot number " + number + " was removed.");
        
        return null;
    }
}
